package com.skyframe.animator.core;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;

/** One PNG folder plus a bounded decoded-frame cache and a single background decoder. */
public final class AnimationSequence {
    private static final long MAX_PIXELS = 4L * 1024L * 1024L;

    private final File directory;
    private final List<File> frames;
    private final int cacheLimit;
    private final ExecutorService loader;
    private final LinkedHashMap<Integer, FrameData> cache = new LinkedHashMap<Integer, FrameData>(16, 0.75F, true);
    private final Set<Integer> pending = new HashSet<Integer>();
    private final Set<Integer> failed = new HashSet<Integer>();
    private int referenceWidth = -1;
    private int referenceHeight = -1;
    private volatile String lastError = "";

    public AnimationSequence(File directory, int cacheLimit) {
        this.directory = directory;
        this.cacheLimit = Math.max(1, Math.min(8, cacheLimit));
        this.frames = discoverFrames(directory);
        this.loader = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "SkyFrame-PNG-Loader");
            t.setDaemon(true);
            return t;
        });
    }

    public String getName() { return directory.getName(); }
    public File getDirectory() { return directory; }
    public int size() { return frames.size(); }
    public String getLastError() { return lastError; }

    public static List<File> discoverFolders(File root) {
        if (!root.exists()) root.mkdirs();
        File[] entries = root.listFiles(File::isDirectory);
        List<File> result = new ArrayList<File>();
        if (entries != null) {
            for (File entry : entries) {
                if (!entry.isHidden()) result.add(entry);
            }
        }
        Collections.sort(result, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    private static List<File> discoverFrames(File directory) {
        File[] entries = directory.listFiles(file -> file.isFile() && file.getName().toLowerCase(Locale.ROOT).endsWith(".png"));
        List<File> list = new ArrayList<File>();
        if (entries != null) Collections.addAll(list, entries);
        Collections.sort(list, AnimationSequence::naturalCompare);
        return list;
    }

    private static int naturalCompare(File a, File b) {
        String aa = a.getName().toLowerCase(Locale.ROOT);
        String bb = b.getName().toLowerCase(Locale.ROOT);
        int i = 0, j = 0;
        while (i < aa.length() && j < bb.length()) {
            char ca = aa.charAt(i), cb = bb.charAt(j);
            if (Character.isDigit(ca) && Character.isDigit(cb)) {
                int ai = i, bj = j;
                while (i < aa.length() && Character.isDigit(aa.charAt(i))) i++;
                while (j < bb.length() && Character.isDigit(bb.charAt(j))) j++;
                String as = aa.substring(ai, i), bs = bb.substring(bj, j);
                int cmp;
                try { cmp = new BigInteger(as).compareTo(new BigInteger(bs)); }
                catch (NumberFormatException ex) { cmp = as.compareTo(bs); }
                if (cmp != 0) return cmp;
                if (as.length() != bs.length()) return Integer.compare(as.length(), bs.length());
            } else {
                if (ca != cb) return Character.compare(ca, cb);
                i++; j++;
            }
        }
        return Integer.compare(aa.length(), bb.length());
    }

    public synchronized FrameData getCachedFrame(int index) {
        return cache.get(index);
    }

    public synchronized boolean isFailed(int index) { return failed.contains(index); }

    public void requestFrame(final int index) {
        if (index < 0 || index >= frames.size()) return;
        synchronized (this) {
            if (cache.containsKey(index) || pending.contains(index) || failed.contains(index)) return;
            pending.add(index);
        }
        loader.submit(() -> decode(index));
    }

    private void decode(int index) {
        File file = frames.get(index);
        try {
            BufferedImage image = ImageIO.read(file);
            if (image == null) throw new IOException("Arquivo nao e um PNG valido: " + file.getName());
            int w = image.getWidth();
            int h = image.getHeight();
            if (w < 1 || h < 1 || w > 4096 || h > 4096 || (long) w * (long) h > MAX_PIXELS) {
                image.flush();
                throw new IOException("Dimensao invalida ou grande demais em " + file.getName() + " (limite de 4 megapixels; maximo 4096 px por lado)");
            }
            int[] pixels = image.getRGB(0, 0, w, h, null, 0, w);
            image.flush();
            FrameData data = new FrameData(w, h, pixels);
            synchronized (this) {
                if (referenceWidth < 0) {
                    referenceWidth = w;
                    referenceHeight = h;
                }
                if (w != referenceWidth || h != referenceHeight) {
                    failed.add(index);
                    lastError = "Frame " + (index + 1) + " tem dimensao diferente; todos os PNGs devem ter o mesmo tamanho.";
                } else {
                    cache.put(index, data);
                    while (cache.size() > cacheLimit) {
                        Integer eldest = cache.keySet().iterator().next();
                        cache.remove(eldest);
                    }
                }
            }
        } catch (Exception ex) {
            synchronized (this) { failed.add(index); }
            lastError = ex.getMessage() == null ? "Falha ao ler frame " + (index + 1) : ex.getMessage();
            System.err.println("[SkyFrame Animator] " + lastError);
        } finally {
            synchronized (this) { pending.remove(index); }
        }
    }

    public void close() {
        loader.shutdownNow();
        synchronized (this) {
            cache.clear();
            pending.clear();
        }
    }
}
