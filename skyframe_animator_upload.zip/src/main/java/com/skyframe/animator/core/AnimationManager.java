package com.skyframe.animator.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Owns the selected sequence and playback clock. All control methods are called from the client thread. */
public final class AnimationManager {
    public enum PlaybackState { STOPPED, PLAYING, PAUSED }

    private final File rootDirectory;
    private final Settings settings;
    private List<File> folders = new ArrayList<File>();
    private AnimationSequence sequence;
    private int currentFrame;
    private PlaybackState state = PlaybackState.STOPPED;
    private String status = "Nenhuma animacao selecionada";
    private long lastUpdateNanos = 0L;
    private long accumulatedNanos = 0L;

    public AnimationManager(File rootDirectory, Settings settings) {
        this.rootDirectory = rootDirectory;
        this.settings = settings;
        refreshAnimations();
        File selected = findFolder(settings.selectedAnimation);
        if (selected != null) selectAnimation(selected.getName());
    }

    public List<String> getAnimationNames() {
        List<String> names = new ArrayList<String>();
        for (File f : folders) names.add(f.getName());
        return Collections.unmodifiableList(names);
    }

    public List<File> getAnimationFolders() { return Collections.unmodifiableList(folders); }
    public AnimationSequence getSequence() { return sequence; }
    public boolean hasSequence() { return sequence != null && sequence.size() > 0; }
    public int getFrameCount() { return sequence == null ? 0 : sequence.size(); }
    public int getCurrentFrameIndex() { return currentFrame; }
    public String getStatusText() { return status; }
    public PlaybackState getPlaybackState() { return state; }
    public String getSelectedAnimationName() { return sequence == null ? "(nenhuma)" : sequence.getName(); }

    public void refreshAnimations() {
        folders = AnimationSequence.discoverFolders(rootDirectory);
        status = folders.isEmpty()
                ? "Crie uma pasta em config/skyframe_animator/"
                : "Encontradas " + folders.size() + " pasta(s) de animacao";
    }

    private File findFolder(String name) {
        if (name == null || name.trim().isEmpty()) return null;
        for (File f : folders) if (f.getName().equals(name)) return f;
        return null;
    }

    public void selectAnimation(String name) {
        File folder = findFolder(name);
        if (folder == null) {
            status = "Pasta nao encontrada: " + name;
            return;
        }
        if (sequence != null) sequence.close();
        sequence = new AnimationSequence(folder, settings.cacheFrames);
        settings.selectedAnimation = folder.getName();
        if (sequence.size() > 0) {
            settings.startFrame = Math.max(0, Math.min(sequence.size() - 1, settings.startFrame));
            if (settings.endFrame >= 0) {
                settings.endFrame = Math.max(settings.startFrame, Math.min(sequence.size() - 1, settings.endFrame));
            }
        }
        settings.save();
        currentFrame = getStartFrame();
        state = PlaybackState.STOPPED;
        accumulatedNanos = 0L;
        lastUpdateNanos = System.nanoTime();
        if (sequence.size() == 0) {
            status = "A pasta '" + name + "' nao contem arquivos PNG.";
        } else {
            status = "Carregada lista: " + sequence.size() + " frame(s). Decodificacao sob demanda.";
            requestAroundCurrentFrame();
        }
    }

    public void play() {
        if (!hasSequence()) {
            status = "Selecione uma pasta que contenha PNGs primeiro.";
            return;
        }
        currentFrame = getStartFrame();
        state = PlaybackState.PLAYING;
        accumulatedNanos = 0L;
        lastUpdateNanos = System.nanoTime();
        status = "Reproduzindo";
        requestAroundCurrentFrame();
    }

    public void restart() { play(); }

    public void pauseResume() {
        if (!hasSequence()) {
            status = "Nenhuma sequencia carregada.";
        } else if (state == PlaybackState.PLAYING) {
            updatePlaybackClock();
            state = PlaybackState.PAUSED;
            status = "Pausada no frame " + (currentFrame + 1);
        } else {
            if (state == PlaybackState.STOPPED) currentFrame = getStartFrame();
            state = PlaybackState.PLAYING;
            lastUpdateNanos = System.nanoTime();
            accumulatedNanos = 0L;
            status = "Reproduzindo";
            requestAroundCurrentFrame();
        }
    }

    public void pause() {
        if (state == PlaybackState.PLAYING) pauseResume();
    }

    public void stop() {
        state = PlaybackState.STOPPED;
        currentFrame = getStartFrame();
        accumulatedNanos = 0L;
        lastUpdateNanos = System.nanoTime();
        status = "Parada; posicionada no frame " + (currentFrame + 1);
        requestAroundCurrentFrame();
    }

    public void updatePlaybackClock() {
        long now = System.nanoTime();
        long elapsed = lastUpdateNanos == 0L ? 0L : now - lastUpdateNanos;
        lastUpdateNanos = now;
        // Avoid a large jump if the window was minimized or another GUI paused world rendering.
        if (elapsed < 0L || elapsed > 250_000_000L) elapsed = 0L;
        if (state == PlaybackState.PLAYING && hasSequence()) {
            accumulatedNanos += elapsed;
            long frameDuration = 1_000_000_000L / Math.max(1, Math.min(60, settings.fps));
            long stepsLong = accumulatedNanos / frameDuration;
            if (stepsLong > 0L) {
                accumulatedNanos %= frameDuration;
                int start = getStartFrame();
                int end = getEndFrame();
                long next = (long) currentFrame + stepsLong;
                if (next > end) {
                    if (settings.loop) {
                        int span = Math.max(1, end - start + 1);
                        currentFrame = start + (int) ((next - start) % span);
                    } else {
                        currentFrame = end;
                        state = PlaybackState.STOPPED;
                        status = "Concluida (reproducao unica)";
                    }
                } else {
                    currentFrame = (int) next;
                }
            }
        }
        skipKnownFailedFrames();
        requestAroundCurrentFrame();
    }

    private void skipKnownFailedFrames() {
        if (sequence == null || sequence.size() == 0) return;
        int start = getStartFrame();
        int end = getEndFrame();
        int attempts = 0;
        while (sequence.isFailed(currentFrame) && attempts++ <= (end - start)) {
            status = "Pulando frame invalido " + (currentFrame + 1);
            if (currentFrame >= end) {
                if (settings.loop) currentFrame = start;
                else { state = PlaybackState.STOPPED; return; }
            } else currentFrame++;
        }
    }

    public void requestAroundCurrentFrame() {
        if (!hasSequence()) return;
        int start = getStartFrame();
        int end = getEndFrame();
        for (int offset = 0; offset < settings.cacheFrames; offset++) {
            int idx = currentFrame + offset;
            if (idx > end) {
                if (settings.loop) idx = start + ((idx - start) % Math.max(1, end - start + 1));
                else break;
            }
            sequence.requestFrame(idx);
        }
    }

    public FrameData getCurrentFrameData() {
        if (!hasSequence()) return null;
        FrameData data = sequence.getCachedFrame(currentFrame);
        if (data == null && sequence.isFailed(currentFrame)) skipKnownFailedFrames();
        return data;
    }

    public void clampCurrentFrameToRange() {
        if (hasSequence()) {
            currentFrame = Math.max(getStartFrame(), Math.min(getEndFrame(), currentFrame));
            requestAroundCurrentFrame();
        }
    }

    private int getStartFrame() {
        int size = getFrameCount();
        if (size <= 0) return 0;
        return Math.max(0, Math.min(size - 1, settings.startFrame));
    }

    private int getEndFrame() {
        int size = getFrameCount();
        if (size <= 0) return 0;
        int start = getStartFrame();
        int end = settings.endFrame < 0 ? size - 1 : Math.min(size - 1, settings.endFrame);
        return Math.max(start, end);
    }

    public void shutdown() {
        if (sequence != null) sequence.close();
    }
}
