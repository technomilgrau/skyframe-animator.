package com.skyframe.animator.core;

/** Decoded pixels. Produced on a worker thread; uploaded to the GPU on the render thread. */
public final class FrameData {
    public final int width;
    public final int height;
    public final int[] argb;

    public FrameData(int width, int height, int[] argb) {
        this.width = width;
        this.height = height;
        this.argb = argb;
    }
}
