package com.skyframe.animator.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/** Persistent user settings. This class has no client-only Minecraft references. */
public final class Settings {
    public final File rootDirectory;
    public final File settingsFile;

    public String selectedAnimation = "gyro";
    public int fps = 24;
    public boolean loop = true;
    public boolean autoPlayOnWorldJoin = false;
    public boolean relativeToCamera = true;
    public boolean billboard = true;
    public boolean preserveAspect = true;
    public double width = 10.0D;
    public double height = 10.0D;
    public double x = 0.0D;
    public double y = 0.0D;
    public double z = 0.0D;
    public double distance = 30.0D;
    public float rotationX = 0.0F;
    public float rotationY = 0.0F;
    public float rotationZ = 0.0F;
    /** Zero-based inclusive frame index. */
    public int startFrame = 0;
    /** Zero-based inclusive frame index; -1 means the last frame. */
    public int endFrame = -1;
    public int cacheFrames = 3;

    public Settings(File rootDirectory) {
        this.rootDirectory = rootDirectory;
        this.settingsFile = new File(rootDirectory, "settings.properties");
    }

    public void load() {
        if (!rootDirectory.exists() && !rootDirectory.mkdirs()) {
            System.err.println("[SkyFrame Animator] Nao foi possivel criar: " + rootDirectory);
        }
        if (!settingsFile.isFile()) {
            save();
            return;
        }
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(settingsFile)) {
            p.load(in);
            selectedAnimation = p.getProperty("animation", selectedAnimation);
            fps = clamp(parseInt(p, "fps", fps), 1, 60);
            loop = parseBoolean(p, "loop", loop);
            autoPlayOnWorldJoin = parseBoolean(p, "autoPlayOnWorldJoin", autoPlayOnWorldJoin);
            relativeToCamera = parseBoolean(p, "relativeToCamera", relativeToCamera);
            billboard = parseBoolean(p, "billboard", billboard);
            preserveAspect = parseBoolean(p, "preserveAspect", preserveAspect);
            width = clamp(parseDouble(p, "width", width), 0.05D, 10000.0D);
            height = clamp(parseDouble(p, "height", height), 0.05D, 10000.0D);
            x = clamp(parseDouble(p, "x", x), -30000000D, 30000000D);
            y = clamp(parseDouble(p, "y", y), -30000000D, 30000000D);
            z = clamp(parseDouble(p, "z", z), -30000000D, 30000000D);
            distance = clamp(parseDouble(p, "distance", distance), 0.1D, 10000.0D);
            rotationX = (float) clamp(parseDouble(p, "rotationX", rotationX), -36000D, 36000D);
            rotationY = (float) clamp(parseDouble(p, "rotationY", rotationY), -36000D, 36000D);
            rotationZ = (float) clamp(parseDouble(p, "rotationZ", rotationZ), -36000D, 36000D);
            startFrame = Math.max(0, parseInt(p, "startFrame", startFrame));
            endFrame = Math.max(-1, parseInt(p, "endFrame", endFrame));
            cacheFrames = clamp(parseInt(p, "cacheFrames", cacheFrames), 1, 8);
        } catch (IOException ex) {
            System.err.println("[SkyFrame Animator] Erro lendo settings.properties: " + ex.getMessage());
        }
    }

    public void save() {
        if (!rootDirectory.exists() && !rootDirectory.mkdirs()) {
            System.err.println("[SkyFrame Animator] Nao foi possivel criar: " + rootDirectory);
            return;
        }
        Properties p = new Properties();
        p.setProperty("animation", selectedAnimation == null ? "" : selectedAnimation);
        p.setProperty("fps", Integer.toString(clamp(fps, 1, 60)));
        p.setProperty("loop", Boolean.toString(loop));
        p.setProperty("autoPlayOnWorldJoin", Boolean.toString(autoPlayOnWorldJoin));
        p.setProperty("relativeToCamera", Boolean.toString(relativeToCamera));
        p.setProperty("billboard", Boolean.toString(billboard));
        p.setProperty("preserveAspect", Boolean.toString(preserveAspect));
        p.setProperty("width", Double.toString(width));
        p.setProperty("height", Double.toString(height));
        p.setProperty("x", Double.toString(x));
        p.setProperty("y", Double.toString(y));
        p.setProperty("z", Double.toString(z));
        p.setProperty("distance", Double.toString(distance));
        p.setProperty("rotationX", Float.toString(rotationX));
        p.setProperty("rotationY", Float.toString(rotationY));
        p.setProperty("rotationZ", Float.toString(rotationZ));
        p.setProperty("startFrame", Integer.toString(startFrame));
        p.setProperty("endFrame", Integer.toString(endFrame));
        p.setProperty("cacheFrames", Integer.toString(clamp(cacheFrames, 1, 8)));
        try (FileOutputStream out = new FileOutputStream(settingsFile)) {
            p.store(out, "SkyFrame Animator - configuracao; frame indices are zero-based");
        } catch (IOException ex) {
            System.err.println("[SkyFrame Animator] Erro salvando settings.properties: " + ex.getMessage());
        }
    }

    private static int parseInt(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback)).trim()); }
        catch (RuntimeException ignored) { return fallback; }
    }
    private static double parseDouble(Properties p, String key, double fallback) {
        try { return Double.parseDouble(p.getProperty(key, Double.toString(fallback)).trim()); }
        catch (RuntimeException ignored) { return fallback; }
    }
    private static boolean parseBoolean(Properties p, String key, boolean fallback) {
        String v = p.getProperty(key);
        return v == null ? fallback : Boolean.parseBoolean(v.trim());
    }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
