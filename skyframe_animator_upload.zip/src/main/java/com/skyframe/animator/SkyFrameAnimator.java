package com.skyframe.animator;

import com.skyframe.animator.core.Settings;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppingEvent;

@Mod(modid = SkyFrameAnimator.MODID, name = SkyFrameAnimator.NAME, version = SkyFrameAnimator.VERSION,
     acceptedMinecraftVersions = "[1.12.2]")
public final class SkyFrameAnimator {
    public static final String MODID = "skyframe_animator";
    public static final String NAME = "SkyFrame Animator";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static SkyFrameAnimator INSTANCE;

    @SidedProxy(clientSide = "com.skyframe.animator.client.ClientProxy", serverSide = "com.skyframe.animator.CommonProxy")
    public static CommonProxy PROXY;

    public static Settings SETTINGS;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        FileDirectoryHolder holder = new FileDirectoryHolder(new java.io.File(event.getModConfigurationDirectory(), "skyframe_animator"));
        SETTINGS = new Settings(holder.directory);
        SETTINGS.load();
        PROXY.preInit(holder.directory, SETTINGS);
    }

    @Mod.EventHandler
    public void serverStopping(FMLServerStoppingEvent event) {
        // The client proxy is responsible for its own worker cleanup when the client shuts down.
    }

    private static final class FileDirectoryHolder {
        final java.io.File directory;
        FileDirectoryHolder(java.io.File directory) { this.directory = directory; }
    }
}
