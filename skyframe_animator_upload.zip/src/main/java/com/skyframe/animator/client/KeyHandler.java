package com.skyframe.animator.client;

import com.skyframe.animator.core.AnimationManager;
import com.skyframe.animator.core.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public final class KeyHandler {
    public static KeyBinding PLAY;
    public static KeyBinding PAUSE_RESUME;
    public static KeyBinding STOP;
    public static KeyBinding OPEN_GUI;

    private final AnimationManager manager;
    private final Settings settings;
    private boolean wasInWorld = false;

    public KeyHandler(AnimationManager manager, Settings settings) {
        this.manager = manager;
        this.settings = settings;
    }

    public static void registerKeys() {
        PLAY = new KeyBinding("key.skyframe.play", Keyboard.KEY_P, "key.categories.skyframe");
        PAUSE_RESUME = new KeyBinding("key.skyframe.pause", Keyboard.KEY_O, "key.categories.skyframe");
        STOP = new KeyBinding("key.skyframe.stop", Keyboard.KEY_K, "key.categories.skyframe");
        OPEN_GUI = new KeyBinding("key.skyframe.gui", Keyboard.KEY_U, "key.categories.skyframe");
        ClientRegistry.registerKeyBinding(PLAY);
        ClientRegistry.registerKeyBinding(PAUSE_RESUME);
        ClientRegistry.registerKeyBinding(STOP);
        ClientRegistry.registerKeyBinding(OPEN_GUI);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        boolean inWorld = mc.player != null && mc.world != null;
        if (!inWorld) {
            wasInWorld = false;
            return;
        }
        if (!wasInWorld) {
            wasInWorld = true;
            if (settings.autoPlayOnWorldJoin) manager.play();
        }
        if (PLAY.isPressed()) manager.play();
        if (PAUSE_RESUME.isPressed()) manager.pauseResume();
        if (STOP.isPressed()) manager.stop();
        if (OPEN_GUI.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new SkyFrameGui(manager, settings));
        }
    }
}
