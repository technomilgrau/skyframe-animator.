package com.skyframe.animator.client;

import com.skyframe.animator.core.AnimationManager;
import com.skyframe.animator.core.AnimationSequence;
import com.skyframe.animator.core.FrameData;
import com.skyframe.animator.core.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

@SideOnly(Side.CLIENT)
public final class SkyFrameRenderer {
    private final AnimationManager manager;
    private final Settings settings;
    private final Minecraft mc = Minecraft.getMinecraft();
    private AnimationSequence textureSequence;
    private DynamicTexture dynamicTexture;
    private ResourceLocation textureLocation;
    private int textureFrameIndex = -1;
    private int textureWidth;
    private int textureHeight;

    public SkyFrameRenderer(AnimationManager manager, Settings settings) {
        this.manager = manager;
        this.settings = settings;
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (mc.player == null || mc.world == null || !manager.hasSequence()) return;

        manager.updatePlaybackClock();
        AnimationSequence sequence = manager.getSequence();
        if (sequence != textureSequence) {
            disposeTexture();
            textureSequence = sequence;
        }

        FrameData frame = manager.getCurrentFrameData();
        if (frame != null && (dynamicTexture == null || textureFrameIndex != manager.getCurrentFrameIndex())) {
            uploadFrame(frame, manager.getCurrentFrameIndex());
        }
        // If the requested frame is still being decoded, keep the previous texture from this same sequence.
        if (dynamicTexture == null || textureLocation == null) return;

        float partialTicks = event.getPartialTicks();
        Vec3d center = getWorldCenter(partialTicks);
        double relX = center.x - mc.getRenderManager().viewerPosX;
        double relY = center.y - mc.getRenderManager().viewerPosY;
        double relZ = center.z - mc.getRenderManager().viewerPosZ;

        double drawWidth = Math.max(0.05D, settings.width);
        double drawHeight = Math.max(0.05D, settings.height);
        if (settings.preserveAspect && textureWidth > 0) {
            drawHeight = drawWidth * ((double) textureHeight / (double) textureWidth);
        }

        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate(relX, relY, relZ);
            if (settings.billboard) {
                GlStateManager.rotate(180.0F - mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                GlStateManager.rotate(-mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
            } else {
                GlStateManager.rotate(settings.rotationY, 0.0F, 1.0F, 0.0F);
                GlStateManager.rotate(settings.rotationX, 1.0F, 0.0F, 0.0F);
            }
            GlStateManager.rotate(settings.rotationZ, 0.0F, 0.0F, 1.0F);

            mc.getTextureManager().bindTexture(textureLocation);
            GlStateManager.enableTexture2D();
            GlStateManager.enableDepth();
            GlStateManager.depthMask(false);
            GlStateManager.disableLighting();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0); // SRC_ALPHA, ONE_MINUS_SRC_ALPHA
            GlStateManager.disableCull();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

            double halfW = drawWidth / 2.0D;
            double halfH = drawHeight / 2.0D;
            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder buffer = tessellator.getBuffer();
            buffer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
            buffer.pos(-halfW, -halfH, 0.0D).tex(0.0D, 1.0D).endVertex();
            buffer.pos( halfW, -halfH, 0.0D).tex(1.0D, 1.0D).endVertex();
            buffer.pos( halfW,  halfH, 0.0D).tex(1.0D, 0.0D).endVertex();
            buffer.pos(-halfW,  halfH, 0.0D).tex(0.0D, 0.0D).endVertex();
            tessellator.draw();
        } catch (RuntimeException ex) {
            System.err.println("[SkyFrame Animator] Erro ao renderizar o billboard: " + ex.getMessage());
        } finally {
            GlStateManager.enableCull();
            GlStateManager.disableBlend();
            GlStateManager.depthMask(true);
            GlStateManager.enableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.popMatrix();
        }
    }

    private Vec3d getWorldCenter(float partialTicks) {
        if (!settings.relativeToCamera) return new Vec3d(settings.x, settings.y, settings.z);
        Vec3d eye = mc.player.getPositionEyes(partialTicks);
        Vec3d look = mc.player.getLook(partialTicks).normalize();
        Vec3d worldUp = new Vec3d(0.0D, 1.0D, 0.0D);
        Vec3d right = look.crossProduct(worldUp);
        if (right.lengthSquared() < 1.0E-5D) right = new Vec3d(1.0D, 0.0D, 0.0D);
        else right = right.normalize();
        Vec3d cameraUp = right.crossProduct(look).normalize();
        return eye.add(look.scale(settings.distance + settings.z))
                  .add(right.scale(settings.x))
                  .add(cameraUp.scale(settings.y));
    }

    private void uploadFrame(FrameData frame, int index) {
        try {
            if (dynamicTexture == null || frame.width != textureWidth || frame.height != textureHeight) {
                disposeTexture();
                textureWidth = frame.width;
                textureHeight = frame.height;
                dynamicTexture = new DynamicTexture(frame.width, frame.height);
                textureLocation = mc.getTextureManager().getDynamicTextureLocation("skyframe_animator_frame", dynamicTexture);
                GlStateManager.bindTexture(dynamicTexture.getGlTextureId());
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_CLAMP_TO_EDGE);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_CLAMP_TO_EDGE);
            }
            int[] target = dynamicTexture.getTextureData();
            System.arraycopy(frame.argb, 0, target, 0, Math.min(frame.argb.length, target.length));
            dynamicTexture.updateDynamicTexture();
            textureFrameIndex = index;
        } catch (RuntimeException ex) {
            System.err.println("[SkyFrame Animator] Erro ao enviar frame para a GPU: " + ex.getMessage());
        }
    }

    private void disposeTexture() {
        if (textureLocation != null) {
            mc.getTextureManager().deleteTexture(textureLocation);
        }
        textureLocation = null;
        dynamicTexture = null;
        textureFrameIndex = -1;
        textureWidth = 0;
        textureHeight = 0;
    }
}
