package com.skyframe.animator.client;

import com.skyframe.animator.CommonProxy;
import com.skyframe.animator.core.AnimationManager;
import com.skyframe.animator.core.Settings;
import java.io.File;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public final class ClientProxy extends CommonProxy {
    public static AnimationManager MANAGER;
    public static KeyHandler KEY_HANDLER;
    private Settings settings;

    @Override
    public void preInit(File rootDirectory, Settings settings) {
        this.settings = settings;
        MANAGER = new AnimationManager(rootDirectory, settings);
        KEY_HANDLER = new KeyHandler(MANAGER, settings);
        KeyHandler.registerKeys();
        FMLCommonHandler.instance().bus().register(KEY_HANDLER);
        MinecraftForge.EVENT_BUS.register(KEY_HANDLER);
        MinecraftForge.EVENT_BUS.register(new SkyFrameRenderer(MANAGER, settings));
    }
}
