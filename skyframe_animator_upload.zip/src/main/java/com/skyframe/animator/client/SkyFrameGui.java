package com.skyframe.animator.client;

import com.skyframe.animator.core.AnimationManager;
import com.skyframe.animator.core.Settings;
import java.io.IOException;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Mouse;

@SideOnly(Side.CLIENT)
public final class SkyFrameGui extends GuiScreen {
    private static final int PLAY = 1, PAUSE = 2, STOP = 3, RELOAD = 4;
    private static final int FPS_DOWN = 10, FPS_UP = 11, LOOP = 12, AUTO_PLAY = 13;
    private static final int NEXT_PAGE = 14, PREVIOUS_PAGE = 15;
    private static final int WIDTH_DOWN = 100, WIDTH_UP = 101, HEIGHT_DOWN = 102, HEIGHT_UP = 103;
    private static final int X_DOWN = 104, X_UP = 105, Y_DOWN = 106, Y_UP = 107, Z_DOWN = 108, Z_UP = 109;
    private static final int DIST_DOWN = 110, DIST_UP = 111, START_DOWN = 112, START_UP = 113, END_DOWN = 114, END_UP = 115;
    private static final int ROTX_DOWN = 116, ROTX_UP = 117, ROTY_DOWN = 118, ROTY_UP = 119, ROTZ_DOWN = 120, ROTZ_UP = 121;
    private static final int RELATIVE = 122, BILLBOARD = 123, ASPECT = 124;

    private final AnimationManager manager;
    private final Settings settings;
    private int page = 0;
    private int folderScroll = 0;
    private int leftWidth;
    private int panelX;
    private int panelWidth;

    public SkyFrameGui(AnimationManager manager, Settings settings) {
        this.manager = manager;
        this.settings = settings;
    }

    @Override
    public void initGui() {
        buttonList.clear();
        leftWidth = Math.max(170, width * 39 / 100);
        panelX = leftWidth + 10;
        panelWidth = Math.max(100, width - panelX - 8);
        int half = Math.max(48, (panelWidth - 6) / 2);
        if (page == 0) {
            addPair(PLAY, "Play", PAUSE, "Pause/Resume", STOP, "Stop", 88, true);
            addPair(FPS_DOWN, "FPS -", FPS_UP, "FPS +", 116);
            addPair(LOOP, loopLabel(), AUTO_PLAY, autoPlayLabel(), 140);
            addPair(RELOAD, "Atualizar pastas", NEXT_PAGE, "Mais ajustes >", 164);
        } else {
            int y = 64;
            addPair(WIDTH_DOWN, "Largura -", WIDTH_UP, "Largura +", y); y += 23;
            addPair(HEIGHT_DOWN, "Altura -", HEIGHT_UP, "Altura +", y); y += 23;
            addPair(X_DOWN, "X -", X_UP, "X +", y); y += 23;
            addPair(Y_DOWN, "Y -", Y_UP, "Y +", y); y += 23;
            addPair(Z_DOWN, "Z -", Z_UP, "Z +", y); y += 23;
            addPair(DIST_DOWN, "Dist. -", DIST_UP, "Dist. +", y); y += 23;
            addPair(START_DOWN, "Inicio -", START_UP, "Inicio +", y); y += 23;
            addPair(END_DOWN, "Fim -", END_UP, "Fim +", y); y += 23;
            addPair(ROTX_DOWN, "Rot X -", ROTX_UP, "Rot X +", y); y += 23;
            addPair(ROTY_DOWN, "Rot Y -", ROTY_UP, "Rot Y +", y); y += 23;
            addPair(ROTZ_DOWN, "Rot Z -", ROTZ_UP, "Rot Z +", y); y += 23;
            addPair(RELATIVE, relativeLabel(), BILLBOARD, billboardLabel(), y); y += 23;
            addPair(ASPECT, aspectLabel(), PREVIOUS_PAGE, "< Voltar", y);
        }
    }

    private void addPair(int leftId, String leftLabel, int rightId, String rightLabel, int y) {
        int half = Math.max(48, (panelWidth - 6) / 2);
        buttonList.add(new GuiButton(leftId, panelX, y, half, 20, leftLabel));
        buttonList.add(new GuiButton(rightId, panelX + half + 6, y, half, 20, rightLabel));
    }

    private void addPair(int firstId, String firstLabel, int secondId, String secondLabel, int thirdId, String thirdLabel, int y, boolean triple) {
        int gap = 3;
        int w = Math.max(42, (panelWidth - gap * 2) / 3);
        buttonList.add(new GuiButton(firstId, panelX, y, w, 20, firstLabel));
        buttonList.add(new GuiButton(secondId, panelX + w + gap, y, w, 20, secondLabel));
        buttonList.add(new GuiButton(thirdId, panelX + 2 * (w + gap), y, w, 20, thirdLabel));
    }

    private String loopLabel() { return "Loop: " + (settings.loop ? "ON" : "OFF"); }
    private String autoPlayLabel() { return "Auto: " + (settings.autoPlayOnWorldJoin ? "ON" : "OFF"); }
    private String relativeLabel() { return settings.relativeToCamera ? "Relativo: ON" : "Mundo: ON"; }
    private String billboardLabel() { return "Billboard: " + (settings.billboard ? "ON" : "OFF"); }
    private String aspectLabel() { return "Proporcao: " + (settings.preserveAspect ? "ON" : "OFF"); }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (!button.enabled) return;
        switch (button.id) {
            case PLAY: manager.play(); break;
            case PAUSE: manager.pauseResume(); break;
            case STOP: manager.stop(); break;
            case RELOAD:
                String current = settings.selectedAnimation;
                manager.refreshAnimations();
                if (current != null) manager.selectAnimation(current);
                folderScroll = 0;
                break;
            case FPS_DOWN: settings.fps = previousPresetFps(settings.fps); save(); break;
            case FPS_UP: settings.fps = nextPresetFps(settings.fps); save(); break;
            case LOOP: settings.loop = !settings.loop; save(); break;
            case AUTO_PLAY: settings.autoPlayOnWorldJoin = !settings.autoPlayOnWorldJoin; save(); break;
            case NEXT_PAGE: page = 1; initGui(); break;
            case PREVIOUS_PAGE: page = 0; initGui(); break;
            case WIDTH_DOWN: settings.width = Math.max(0.05D, settings.width - 1.0D); save(); break;
            case WIDTH_UP: settings.width = Math.min(10000D, settings.width + 1.0D); save(); break;
            case HEIGHT_DOWN: settings.height = Math.max(0.05D, settings.height - 1.0D); save(); break;
            case HEIGHT_UP: settings.height = Math.min(10000D, settings.height + 1.0D); save(); break;
            case X_DOWN: settings.x -= 1D; save(); break;
            case X_UP: settings.x += 1D; save(); break;
            case Y_DOWN: settings.y -= 1D; save(); break;
            case Y_UP: settings.y += 1D; save(); break;
            case Z_DOWN: settings.z -= 1D; save(); break;
            case Z_UP: settings.z += 1D; save(); break;
            case DIST_DOWN: settings.distance = Math.max(0.1D, settings.distance - 2D); save(); break;
            case DIST_UP: settings.distance = Math.min(10000D, settings.distance + 2D); save(); break;
            case START_DOWN: settings.startFrame = Math.max(0, settings.startFrame - 1); manager.clampCurrentFrameToRange(); save(); break;
            case START_UP: settings.startFrame = Math.min(Math.max(0, manager.getFrameCount() - 1), settings.startFrame + 1); manager.clampCurrentFrameToRange(); save(); break;
            case END_DOWN:
                if (manager.getFrameCount() > 0) {
                    int end = settings.endFrame < 0 ? manager.getFrameCount() - 1 : settings.endFrame;
                    settings.endFrame = Math.max(settings.startFrame, end - 1);
                }
                manager.clampCurrentFrameToRange(); save(); break;
            case END_UP:
                if (settings.endFrame >= 0) settings.endFrame = Math.min(Math.max(0, manager.getFrameCount() - 1), settings.endFrame + 1);
                manager.clampCurrentFrameToRange(); save(); break;
            case ROTX_DOWN: settings.rotationX -= 5F; save(); break;
            case ROTX_UP: settings.rotationX += 5F; save(); break;
            case ROTY_DOWN: settings.rotationY -= 5F; save(); break;
            case ROTY_UP: settings.rotationY += 5F; save(); break;
            case ROTZ_DOWN: settings.rotationZ -= 5F; save(); break;
            case ROTZ_UP: settings.rotationZ += 5F; save(); break;
            case RELATIVE: settings.relativeToCamera = !settings.relativeToCamera; save(); break;
            case BILLBOARD: settings.billboard = !settings.billboard; save(); break;
            case ASPECT: settings.preserveAspect = !settings.preserveAspect; save(); break;
            default: break;
        }
        if (button.id != NEXT_PAGE && button.id != PREVIOUS_PAGE) initGui();
    }

    private int nextPresetFps(int fps) {
        int[] presets = {12, 24, 30, 60};
        for (int preset : presets) if (preset > fps) return preset;
        return presets[0];
    }

    private int previousPresetFps(int fps) {
        int[] presets = {12, 24, 30, 60};
        for (int i = presets.length - 1; i >= 0; i--) if (presets[i] < fps) return presets[i];
        return presets[presets.length - 1];
    }

    private void save() { settings.save(); }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "SkyFrame Animator", width / 2, 12, 0xFFFFFF);
        drawString(fontRenderer, "Animacoes", 8, 26, 0xE0E0E0);
        drawString(fontRenderer, "Ajustes " + (page + 1) + "/2", panelX, 26, 0xE0E0E0);
        drawRect(6, 40, leftWidth - 4, height - 28, 0x80303030);
        List<String> names = manager.getAnimationNames();
        int rowHeight = 18;
        int visibleRows = Math.max(1, (height - 74) / rowHeight);
        folderScroll = Math.max(0, Math.min(folderScroll, Math.max(0, names.size() - visibleRows)));
        for (int row = 0; row < visibleRows && folderScroll + row < names.size(); row++) {
            int idx = folderScroll + row;
            int y = 43 + row * rowHeight;
            boolean selected = names.get(idx).equals(manager.getSelectedAnimationName());
            if (selected) drawRect(8, y - 1, leftWidth - 6, y + rowHeight - 2, 0xA0606060);
            String name = names.get(idx);
            int maxChars = Math.max(4, (leftWidth - 22) / 6);
            if (name.length() > maxChars) name = name.substring(0, maxChars - 3) + "...";
            drawString(fontRenderer, name, 12, y + 3, selected ? 0xFFFF55 : 0xFFFFFF);
        }
        if (names.isEmpty()) {
            drawString(fontRenderer, "Nenhuma pasta encontrada.", 12, 48, 0xFF7777);
            drawString(fontRenderer, "Crie config/skyframe_animator/gyro/", 12, 64, 0xCCCCCC);
        }

        if (page == 0) {
            drawString(fontRenderer, "Animacao: " + manager.getSelectedAnimationName(), panelX, 42, 0xFFFFFF);
            drawString(fontRenderer, "Estado: " + manager.getPlaybackState().toString(), panelX, 56, 0xDDDDDD);
            int count = manager.getFrameCount();
            int shownFrame = count > 0 ? Math.min(count, manager.getCurrentFrameIndex() + 1) : 0;
            drawString(fontRenderer, "Frame: " + shownFrame + " / " + count + "    FPS: " + settings.fps, panelX, 70, 0xDDDDDD);
        } else {
            drawString(fontRenderer, String.format(java.util.Locale.ROOT, "W %.1f H %.1f  X %.1f Y %.1f Z %.1f", settings.width, settings.height, settings.x, settings.y, settings.z), panelX, 42, 0xBBBBBB);
            drawString(fontRenderer, String.format(java.util.Locale.ROOT, "Dist %.1f  Inicio %d  Fim %s", settings.distance, settings.startFrame + 1, settings.endFrame < 0 ? "ultimo" : Integer.toString(settings.endFrame + 1)), panelX, 52, 0xBBBBBB);
        }
        String status = manager.getStatusText();
        if (status != null && !status.isEmpty()) {
            int maxChars = Math.max(12, (panelWidth - 4) / 6);
            if (status.length() > maxChars) status = status.substring(0, maxChars - 3) + "...";
            drawString(fontRenderer, status, panelX, height - 18, 0xAAAAAA);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton == 0 && mouseX < leftWidth - 3 && mouseY >= 42 && mouseY < height - 28) {
            List<String> names = manager.getAnimationNames();
            int row = (mouseY - 43) / 18;
            int visibleRows = Math.max(1, (height - 74) / 18);
            if (row >= 0 && row < visibleRows) {
                int idx = folderScroll + row;
                if (idx >= 0 && idx < names.size()) {
                    manager.selectAnimation(names.get(idx));
                    initGui();
                    return;
                }
            }
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0 && Mouse.getEventX() < leftWidth * mc.displayWidth / Math.max(1, width)) {
            folderScroll += wheel > 0 ? -3 : 3;
            folderScroll = Math.max(0, Math.min(folderScroll, Math.max(0, manager.getAnimationNames().size() - 1)));
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
