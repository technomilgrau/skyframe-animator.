package com.skyframe.animator;

import com.skyframe.animator.core.Settings;
import java.io.File;

public class CommonProxy {
    public void preInit(File rootDirectory, Settings settings) {
        // Dedicated-server safe: client-only setup is performed by ClientProxy.
    }
}
