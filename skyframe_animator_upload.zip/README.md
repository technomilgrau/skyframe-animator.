# SkyFrame Animator — Forge 1.12.2

Mod client-side para reproduzir sequências de PNG como um plano texturizado no mundo 3D. Ele não depende do Blockbuster e não cria uma entidade por frame.

> **Estado honesto do projeto:** os arquivos-fonte e a configuração Gradle estão montados para Forge 1.12.2, mas este ambiente não tem Gradle/JDK 8 instalado nem acesso de rede para baixar as dependências. Portanto, eu não consegui compilar nem executar este mod aqui. Trate este ZIP como um projeto-fonte para compilar e testar, não como um `.jar` já validado. APIs antigas de renderização também precisam ser confirmadas na primeira compilação real.

## Versões alvo

- Minecraft Java Edition **1.12.2**
- Minecraft Forge **14.23.5.2860**
- Java/JDK **8**
- ForgeGradle **2.3-SNAPSHOT** (configurado no `build.gradle`)
- Gradle **4.10.3** recomendado para este projeto antigo

Não compile este projeto com Java 21/Gradle moderno. O plugin ForgeGradle 2.3 pertence à geração antiga do ecossistema Minecraft.

## Compilar no PC

1. Instale um JDK 8 e o Gradle 4.10.3 no computador.
2. Extraia o ZIP inteiro para uma pasta simples, por exemplo `C:\SkyFrameAnimator`.
3. Abra um terminal **dentro da pasta que contém `build.gradle`**.
4. Confirme as versões usando `java -version` e `gradle -v`. Ambos devem apontar para Java 8 e Gradle 4.10.3.
5. Execute:

   ```text
   gradle build
   ```

6. Na primeira compilação, Gradle baixará Minecraft/Forge/ForgeGradle e suas dependências, então é necessária conexão à internet.
7. Se a compilação terminar em `BUILD SUCCESSFUL`, procure o JAR em `build/libs/`. Use o JAR final que foi reobfuscado pelo ForgeGradle, não um JAR intermediário com sufixo `sources`.

Este ZIP não inclui o `gradle-wrapper.jar`: não consegui baixá-lo no ambiente de criação. Por isso as instruções usam uma instalação local do Gradle 4.10.3 em vez de fingir que `gradlew` está funcional.

## Instalar no Minecraft/PojavLauncher

1. Use uma instalação **Minecraft 1.12.2 + Forge 14.23.5.2860** no perfil que abrirá pelo PojavLauncher.
2. Copie o JAR compilado para a pasta `mods` dessa instalação. No Pojav, o caminho exato depende do diretório `.minecraft` selecionado pelo perfil.
3. Inicie o jogo com o perfil Forge e confira se `SkyFrame Animator` aparece na lista de mods.
4. Entre no mundo e aperte **U** (ou procure “SkyFrame Animator” em Opções → Controles) para abrir a interface.

O mod é principalmente visual/client-side. Para gravação, use o mesmo cliente que tem as imagens. O mod não precisa do Blockbuster. Não há promessa de que o Pojav ou qualquer GPU móvel consiga reproduzir todos os tamanhos/FPS sem engasgos.

## Onde colocar a sequência PNG

O mod cria esta pasta dentro do diretório de configuração do Minecraft:

```text
.minecraft/
└── config/
    └── skyframe_animator/
        ├── settings.properties
        └── gyro/
            ├── 0001.png
            ├── 0002.png
            ├── 0003.png
            └── ...
```

Você pode criar qualquer quantidade de pastas de animação, por exemplo `gyro`, `valentine` ou `teste`. Cada pasta contém diretamente os arquivos `.png` — não são lidas subpastas. Nomes numéricos como `1.png`, `2.png`, `10.png` são ordenados numericamente. Recomendo usar quatro ou mais dígitos (`0001.png`, `0002.png`, …, `1174.png`).

Os PNGs devem ter todos **a mesma largura e altura** e podem conter transparência alfa. O mod limita cada imagem a 4 megapixels e até 4096 pixels em cada lado para reduzir o risco de uso excessivo de memória/limites de textura. Para Pojav, exporte preferencialmente na resolução final necessária (por exemplo, 1280×720 ou 1920×1080) e evite PNGs enormes desnecessários.

Depois de copiar uma nova pasta com o jogo aberto, entre na interface e clique em **Atualizar pastas**. Clique no nome da animação à esquerda para selecioná-la.

## Teclas padrão

As teclas são `KeyBinding` do Forge 1.12.2 e podem ser alteradas em **Opções → Controles → SkyFrame Animator**.

- **P — Play:** começa do frame inicial configurado.
- **O — Pause/Resume:** pausa mantendo o frame ou continua; se estava parada, começa do início.
- **K — Stop/Reset:** para e retorna ao frame inicial.
- **U — Interface:** abre os controles. A interface não pausa o mundo.

Por padrão, entrar no mundo não inicia uma animação. A opção **Auto** na interface habilita início automático ao entrar em um mundo (apenas se uma sequência estiver selecionada e carregada). Deixe desligada se quer preparar câmera e áudio antes de apertar Play.

## Interface

A interface tem duas páginas. Na primeira, selecione a pasta e use Play/Pause/Stop, altere FPS (presets 12, 24, 30 e 60), loop e autoplay. Na segunda, ajuste largura/altura, X/Y/Z, distância, frame inicial/final, rotação, posição relativa à câmera, billboard e proporção.

- **Relativo ON:** X e Y deslocam o plano para os lados/para cima da câmera; distância determina a posição à frente dela; Z é um ajuste adicional na direção da visão.
- **Relativo OFF / Mundo ON:** X/Y/Z são coordenadas do mundo Minecraft.
- **Billboard ON:** o plano vira para acompanhar a câmera.
- **Billboard OFF:** usa orientação fixa; Rot X/Y/Z ajustam a orientação do plano.
- **Proporção ON:** a altura é calculada a partir da largura e das dimensões do PNG. Com OFF, largura e altura são independentes.
- **Início/Fim:** a interface mostra os frames começando em 1. Internamente `settings.properties` usa índices começando em 0; `endFrame=-1` significa o último frame.

Para parecer colossal, use uma largura alta (em blocos) e ajuste a distância. Em modo relativo, mova a câmera para enquadrar e aperte P somente no momento desejado.

## Como o carregamento foi projetado

- O mod mantém uma única `DynamicTexture` e substitui os pixels quando muda de frame, em vez de criar uma nova textura a cada frame.
- PNGs são decodificados numa thread daemon de trabalho; criação/atualização da textura OpenGL ocorre no evento de renderização.
- O cache de pixels é LRU e limitado; padrão 3 frames, configurável de 1 a 8 em `settings.properties` (`cacheFrames`).
- Arquivos inválidos, sequência vazia e PNGs com dimensões incompatíveis são reportados no log/status e frames inválidos são pulados quando possível.
- O plano usa teste de profundidade do mundo, então blocos podem ocultá-lo em vez de sempre aparecer através de paredes. A transparência é preservada com blending.

O cache reduz memória, mas não elimina o custo de decodificar e enviar pixels para a GPU a cada frame. Com 1174 imagens, a quantidade de arquivos não é o principal limite; resolução, FPS, desempenho de armazenamento e GPU são. A 60 FPS a GPU precisa receber até 60 imagens por segundo. Se engasgar, teste 12/24 FPS, cache 2–3 e PNGs menores.

## Diagnóstico e checklist

1. **O mod não aparece:** confirme Forge 1.12.2, que o JAR está na pasta `mods` correta e que foi compilado com `gradle build` sem erros.
2. **A interface mostra zero pastas:** confira se as imagens estão em `.minecraft/config/skyframe_animator/nome/` e clique em Atualizar pastas.
3. **Não aparece imagem:** selecione a pasta, aguarde um instante para decodificar o primeiro PNG e confira se a imagem está à frente da câmera (Relativo ON e Distância 30 são os padrões).
4. **Imagem preta/incompleta ou erro de textura:** reduza a resolução; confira dimensões iguais e PNGs válidos.
5. **Frames fora de ordem:** use nomes numéricos `0001.png`, `0002.png` etc. e não misture nomes arbitrários.
6. **Engasgos:** reduza FPS para 12/24, baixe resolução e mude `cacheFrames` para 1–3.
7. **Crash:** guarde `.minecraft/logs/latest.log` e, se existir, `crash-reports/`. Teste primeiro com Forge sozinho e SkyFrame Animator, sem Blockbuster e sem outros mods de renderização, para isolar conflito.
8. **Falha na compilação:** copie o primeiro erro real do Gradle (não apenas as últimas linhas). Pode ser dependência antiga indisponível, incompatibilidade de Java/Gradle ou uma API de 1.12.2 que exija ajuste.

## Arquivos principais

- `SkyFrameAnimator.java`: entrada do mod e proxy sidesafe.
- `Settings.java`: configuração persistente.
- `AnimationSequence.java`: descoberta numérica, decodificação em background e cache limitado.
- `AnimationManager.java`: playback, FPS, loop, pausa e intervalo de frames.
- `SkyFrameRenderer.java`: billboard no mundo e reutilização da textura.
- `KeyHandler.java`: keybindings do Forge.
- `SkyFrameGui.java`: interface de seleção e ajustes.
